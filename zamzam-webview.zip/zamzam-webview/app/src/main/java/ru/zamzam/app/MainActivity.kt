package ru.zamzam.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

/**
 * Оболочка-WebView для сайта ZamZam.
 *
 * - Сайт открывается внутри приложения, любые другие адреса — во внешнем приложении/браузере.
 * - WhatsApp (заказ и бронь), звонки, почта, карты открываются в соответствующих приложениях.
 * - Окно оплаты ЮMoney (форма с target="_blank") открывается поверх сайта.
 * - «Определить адрес» в форме доставки работает через разрешение на геолокацию.
 * - Нет сети — показывается страница offline.html с кнопкой «Повторить».
 */
class MainActivity : AppCompatActivity() {

    private val siteUrl = BuildConfig.SITE_URL
    private val siteHost = normalizeHost(Uri.parse(siteUrl).host)

    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var popupContainer: View
    private lateinit var popupHost: FrameLayout
    private lateinit var popupTitle: TextView

    private var popupView: WebView? = null
    private var lastFailedUrl: String? = null

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var geoOrigin: String? = null
    private var geoCallback: GeolocationPermissions.Callback? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val granted = result.values.any { it }
            geoCallback?.invoke(geoOrigin, granted, false)
            geoCallback = null
            geoOrigin = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipe = findViewById(R.id.swipe)
        webView = findViewById(R.id.webView)
        progress = findViewById(R.id.progress)
        popupContainer = findViewById(R.id.popupContainer)
        popupHost = findViewById(R.id.popupHost)
        popupTitle = findViewById(R.id.popupTitle)
        findViewById<View>(R.id.popupClose).setOnClickListener { closePopup() }

        webView.setBackgroundColor(Color.TRANSPARENT)
        configure(webView, multiWindow = true)
        webView.webViewClient = MainClient()
        webView.webChromeClient = MainChrome()

        swipe.setColorSchemeResources(R.color.saffron)
        swipe.setOnRefreshListener { reload() }
        // Тянуть для обновления можно только когда страница прокручена к самому верху
        swipe.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    popupView != null -> closePopup()
                    webView.canGoBack() -> webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(siteUrl)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        CookieManager.getInstance().flush() // чтобы вход в личный кабинет не терялся
        super.onPause()
    }

    override fun onDestroy() {
        popupView?.let { it.stopLoading(); it.destroy() }
        popupView = null
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ настройка

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(view: WebView, multiWindow: Boolean) {
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true // localStorage: корзина, токен чата, имя
            setGeolocationEnabled(true)
            setSupportMultipleWindows(multiWindow)
            javaScriptCanOpenWindowsAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false // file:///android_asset/ при этом продолжает работать
            allowContentAccess = false
            userAgentString = "$userAgentString ZamZamApp/${BuildConfig.VERSION_NAME}"
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(view, true) // нужно странице оплаты
        }
    }

    private fun reload() {
        val url = webView.url
        if (url == null || url.startsWith("file:")) {
            webView.loadUrl(lastFailedUrl ?: siteUrl)
        } else {
            webView.reload()
        }
    }

    // ------------------------------------------------------------------ внешние ссылки

    private fun isInternal(uri: Uri): Boolean {
        val host = normalizeHost(uri.host)
        return host == siteHost || host.endsWith(".$siteHost")
    }

    /** true — ссылка ушла во внешнее приложение, в WebView её грузить не нужно. */
    private fun routeExternal(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        return when (scheme) {
            "http", "https" -> {
                val host = normalizeHost(uri.host)
                if (host in EXTERNAL_HOSTS || host.endsWith(".whatsapp.com")) {
                    openExternal(uri)
                    true
                } else {
                    false
                }
            }
            "about", "blob", "data", "javascript", "file", RETRY_SCHEME -> false
            "intent" -> {
                openIntentUri(uri.toString())
                true
            }
            else -> { // tel:, mailto:, whatsapp:, geo:, sms:, tg:, приложения банков и т.д.
                openExternal(uri)
                true
            }
        }
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.cant_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openIntentUri(url: String) {
        try {
            val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                component = null // не даём странице выбирать конкретный компонент
                selector = null
            }
            startActivity(intent)
        } catch (e: Exception) {
            // приложение не установлено — ничего не делаем
        }
    }

    // ------------------------------------------------------------------ окно оплаты

    private fun openPopup(resultMsg: Message) {
        closePopup()
        val popup = WebView(this)
        configure(popup, multiWindow = false)
        popup.webViewClient = PopupClient()
        popup.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView?) = closePopup()
            override fun onReceivedTitle(view: WebView?, title: String?) {
                popupTitle.text = title.orEmpty()
            }
        }
        popupHost.addView(
            popup,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        popupTitle.text = ""
        popupContainer.visibility = View.VISIBLE
        popupView = popup
        swipe.isEnabled = false

        val transport = resultMsg.obj as WebView.WebViewTransport
        transport.webView = popup
        resultMsg.sendToTarget()
    }

    private fun closePopup() {
        val popup = popupView ?: return
        popupView = null
        popupContainer.visibility = View.GONE
        swipe.isEnabled = true
        popupHost.post {
            popupHost.removeView(popup)
            popup.stopLoading()
            popup.destroy()
        }
    }

    // ------------------------------------------------------------------ клиенты WebView

    private inner class MainClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            if (uri.scheme == RETRY_SCHEME) { // кнопка «Повторить» на offline.html
                view.loadUrl(lastFailedUrl ?: siteUrl)
                return true
            }
            if (routeExternal(uri)) return true
            val scheme = uri.scheme?.lowercase()
            if ((scheme == "http" || scheme == "https") && !isInternal(uri)) {
                openExternal(uri) // чужие сайты — в браузер
                return true
            }
            return false
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            progress.progress = 0
            progress.visibility = View.VISIBLE
        }

        override fun onPageFinished(view: WebView, url: String?) {
            progress.visibility = View.GONE
            swipe.isRefreshing = false
            CookieManager.getInstance().flush()
        }

        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError,
        ) {
            if (request.isForMainFrame && !request.url.toString().startsWith("file:")) {
                lastFailedUrl = request.url.toString()
                view.loadUrl(OFFLINE_URL)
            }
        }
    }

    private inner class PopupClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            if (routeExternal(request.url)) {
                if (view.canGoBack().not()) closePopup()
                return true
            }
            return false
        }

        // Первый переход во всплывающем окне не всегда проходит через shouldOverrideUrlLoading
        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            val uri = url?.let { Uri.parse(it) } ?: return
            if (routeExternal(uri)) {
                view.stopLoading()
                closePopup()
            }
        }
    }

    private inner class MainChrome : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            progress.progress = newProgress
        }

        override fun onCreateWindow(
            view: WebView,
            isDialog: Boolean,
            isUserGesture: Boolean,
            resultMsg: Message,
        ): Boolean {
            openPopup(resultMsg)
            return true
        }

        override fun onGeolocationPermissionsShowPrompt(
            origin: String,
            callback: GeolocationPermissions.Callback,
        ) {
            val hasPermission = LOCATION_PERMISSIONS.any {
                ContextCompat.checkSelfPermission(this@MainActivity, it) == PackageManager.PERMISSION_GRANTED
            }
            if (hasPermission) {
                callback.invoke(origin, true, false)
                return
            }
            geoCallback?.invoke(geoOrigin, false, false) // закрываем прошлый незавершённый запрос
            geoOrigin = origin
            geoCallback = callback
            locationPermission.launch(LOCATION_PERMISSIONS)
        }

        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: FileChooserParams,
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            return try {
                fileChooser.launch(params.createIntent())
                true
            } catch (e: ActivityNotFoundException) {
                filePathCallback = null
                false
            }
        }
    }

    companion object {
        private const val OFFLINE_URL = "file:///android_asset/offline.html"
        private const val RETRY_SCHEME = "zamzam-app"

        private val LOCATION_PERMISSIONS = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )

        /** Открываются не в приложении: WhatsApp (заказ и бронь) и карта OpenStreetMap. */
        private val EXTERNAL_HOSTS = setOf(
            "wa.me",
            "whatsapp.com",
            "api.whatsapp.com",
            "web.whatsapp.com",
            "openstreetmap.org",
        )

        private fun normalizeHost(host: String?): String =
            host.orEmpty().lowercase().removePrefix("www.")
    }
}
